// Lightweight localStorage-based fake API to simulate backend
import { Appointment, Bed, Medicine } from '../types';

const LS = {
  beds: 'affordmed_beds',
  appts: 'affordmed_appointments',
  meds: 'affordmed_medicines'
};

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write<T>(key: string, value: T) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error(`Failed to write to localStorage: ${e}`);
  }
}

// Generate UUID fallback for environments without crypto.randomUUID
const generateId = () => {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
};

// Seed demo data once
(function seed() {
  if (!localStorage.getItem(LS.beds)) {
    const demoBeds: Bed[] = [
      { id: generateId(), ward: 'A1', type: 'General', status: 'Available' },
      { id: generateId(), ward: 'B2', type: 'ICU', status: 'Occupied' },
      { id: generateId(), ward: 'ER', type: 'Emergency', status: 'Cleaning' }
    ];
    write(LS.beds, demoBeds);
  }
  if (!localStorage.getItem(LS.appts)) {
    write(LS.appts, [] as Appointment[]);
  }
  if (!localStorage.getItem(LS.meds)) {
    const meds: Medicine[] = [
      { id: generateId(), name: 'Paracetamol 500mg', brand: 'MediCure', stock: 120, price: 25 },
      { id: generateId(), name: 'Amoxicillin 250mg', brand: 'HealPharm', stock: 60, price: 90 },
      { id: generateId(), name: 'ORS Sachet', brand: 'HydraPlus', stock: 200, price: 18 }
    ];
    write(LS.meds, meds);
  }
})();

export const api = {
  // Beds
  async getBeds(): Promise<Bed[]> { return read<Bed[]>(LS.beds, []); },
  async addBed(bed: Omit<Bed, 'id'>): Promise<Bed> {
    const list = read<Bed[]>(LS.beds, []);
    const item: Bed = { id: generateId(), ...bed };
    list.push(item); write(LS.beds, list); return item;
  },
  async updateBed(id: string, patch: Partial<Bed>): Promise<Bed | null> {
    const list = read<Bed[]>(LS.beds, []);
    const idx = list.findIndex(b => b.id === id);
    if (idx === -1) return null;
    list[idx] = { ...list[idx], ...patch }; write(LS.beds, list); return list[idx];
  },
  async deleteBed(id: string): Promise<boolean> {
    const list = read<Bed[]>(LS.beds, []);
    const filtered = list.filter(b => b.id !== id); write(LS.beds, filtered); return filtered.length !== list.length;
  },

  // Appointments
  async getAppointments(): Promise<Appointment[]> { return read<Appointment[]>(LS.appts, []); },
  async addAppointment(a: Omit<Appointment, 'id'>): Promise<Appointment> {
    const list = read<Appointment[]>(LS.appts, []);
    const item: Appointment = { id: generateId(), ...a };
    list.push(item); write(LS.appts, list); return item;
  },
  async cancelAppointment(id: string): Promise<boolean> {
    const list = read<Appointment[]>(LS.appts, []);
    const filtered = list.filter(x => x.id !== id); write(LS.appts, filtered); return filtered.length !== list.length;
  },

  // Medicines
  async getMedicines(): Promise<Medicine[]> { return read<Medicine[]>(LS.meds, []); },
  async upsertMedicine(m: Omit<Medicine, 'id'> & { id?: string }): Promise<Medicine> {
    const list = read<Medicine[]>(LS.meds, []);
    if (m.id) {
      const idx = list.findIndex(x => x.id === m.id);
      if (idx !== -1) { list[idx] = { ...list[idx], ...m } as Medicine; write(LS.meds, list); return list[idx]; }
    }
    const item: Medicine = { id: generateId(), ...m } as Medicine;
    list.push(item); write(LS.meds, list); return item;
  },
  async deleteMedicine(id: string): Promise<boolean> {
    const list = read<Medicine[]>(LS.meds, []);
    const filtered = list.filter(x => x.id !== id); write(LS.meds, filtered); return filtered.length !== list.length;
  }
};