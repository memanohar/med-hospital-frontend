// import { FormEvent, useEffect, useState } from 'react';
// <div className="row">
// <div>
// <label className="label">Department</label>
// <select value={department} onChange={e => setDepartment(e.target.value)}>
// {departments.map(d => <option key={d} value={d}>{d}</option>)}
// </select>
// </div>
// <div>
// <label className="label">Doctor</label>
// <select value={doctor} onChange={e => setDoctor(e.target.value)}>
// {doctorsByDept[department].map(dr => <option key={dr} value={dr}>{dr}</option>)}
// </select>
// </div>
// </div>
// <div className="row">
// <div>
// <label className="label">Date *</label>
// <input className="input" type="date" value={date} onChange={e => setDate(e.target.value)} />
// </div>
// <div>
// <label className="label">Time *</label>
// <input className="input" type="time" value={time} onChange={e => setTime(e.target.value)} />
// </div>
// </div>
// <div>
// <label className="label">Notes</label>
// <textarea className="input" rows={3} value={notes} onChange={e => setNotes(e.target.value)} />
// </div>
// <button className="btn" type="submit">Confirm Booking</button>
// </form>
// </div>


// <div className="card">
// <h3 style={{ marginTop:0 }}>Upcoming Appointments</h3>
// <table className="table">
// <thead>
// <tr><th>Patient</th><th>Doctor</th><th>Date</th><th>Time</th><th>Actions</th></tr>
// </thead>
// <tbody>
// {appointments.map(a => (
// <tr key={a.id}>
// <td>{a.patientName}</td>
// <td>{a.doctor}</td>
// <td>{a.date}</td>
// <td>{a.time}</td>
// <td><button className="btn danger" onClick={() => cancel(a.id)}>Cancel</button></td>
// </tr>
// ))}
// </tbody>
// </table>
// </div>
// </div>
// </div>
// );
// };


// export default Appointments;
import { FormEvent, useState, useEffect } from 'react';
import { Appointment } from '../types';
import { api } from '../api/fakeApi';
import { useHospital } from '../context/HospitalContext';

const departments = ['General Medicine', 'Cardiology', 'Orthopedics', 'Pediatrics', 'Gynecology'];
const doctorsByDept: Record<string, string[]> = {
  'General Medicine': ['Dr. Arjun Rao', 'Dr. Neha Sharma'],
  'Cardiology': ['Dr. K. Menon'],
  'Orthopedics': ['Dr. Amit Verma'],
  'Pediatrics': ['Dr. Ritu Gupta'],
  'Gynecology': ['Dr. Pooja Jain']
};

const Appointments = () => {
  const { appointments, refresh } = useHospital();
  const [patientName, setPatientName] = useState('');
  const [phone, setPhone] = useState('');
  const [department, setDepartment] = useState(departments[0]);
  const [doctor, setDoctor] = useState(doctorsByDept[departments[0]][0]);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [notes, setNotes] = useState('');

  useEffect(() => { setDoctor(doctorsByDept[department][0]); }, [department]);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!patientName || !phone || !date || !time) return alert('Please fill all required fields');
    if (!/^\d{10}$/.test(phone)) return alert('Phone number must be 10 digits');
    const appt: Omit<Appointment, 'id'> = { patientName, phone, department, doctor, date, time, notes };
    await api.addAppointment(appt);
    setPatientName(''); setPhone(''); setNotes(''); setDate(''); setTime('');
    await refresh();
  };

  const cancel = async (id: string) => {
    if (confirm('Cancel this appointment?')) {
      await api.cancelAppointment(id);
      await refresh();
    }
  };

  return (
    <div className="container">
      <h2>Doctor Appointment Booking</h2>
      <div className="grid grid-2">
        <div className="card">
          <h3 style={{ marginTop: 0 }}>Book an Appointment</h3>
          <form onSubmit={onSubmit} className="grid" style={{ gap: 12 }}>
            <div className="row">
              <div>
                <label className="label">Patient Name *</label>
                <input className="input" value={patientName} onChange={e => setPatientName(e.target.value)} />
              </div>
              <div>
                <label className="label">Phone *</label>
                <input className="input" value={phone} onChange={e => setPhone(e.target.value)} placeholder="10-digit" />
              </div>
            </div>
            <div className="row">
              <div>
                <label className="label">Department</label>
                <select value={department} onChange={e => setDepartment(e.target.value)}>
                  {departments.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Doctor</label>
                <select value={doctor} onChange={e => setDoctor(e.target.value)}>
                  {doctorsByDept[department].map(dr => <option key={dr} value={dr}>{dr}</option>)}
                </select>
              </div>
            </div>
            <div className="row">
              <div>
                <label className="label">Date *</label>
                <input className="input" type="date" value={date} onChange={e => setDate(e.target.value)} />
              </div>
              <div>
                <label className="label">Time *</label>
                <input className="input" type="time" value={time} onChange={e => setTime(e.target.value)} />
              </div>
            </div>
            <div>
              <label className="label">Notes</label>
              <textarea className="input" rows={3} value={notes} onChange={e => setNotes(e.target.value)} />
            </div>
            <button className="btn" type="submit">Confirm Booking</button>
          </form>
        </div>

        <div className="card">
          <h3 style={{ marginTop: 0 }}>Upcoming Appointments</h3>
          <table className="table">
            <thead>
              <tr><th>Patient</th><th>Doctor</th><th>Date</th><th>Time</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {appointments.map(a => (
                <tr key={a.id}>
                  <td>{a.patientName}</td>
                  <td>{a.doctor}</td>
                  <td>{new Date(a.date).toLocaleDateString()}</td>
                  <td>{a.time}</td>
                  <td><button className="btn danger" onClick={() => cancel(a.id)}>Cancel</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Appointments;