// import { Service } from '../types';


// const services: Service[] = [
// { id: 's1', title: 'Emergency Care', description: '24/7 emergency services with advanced trauma support.' },
// { id: 's2', title: 'Cardiology', description: 'Non-invasive and interventional cardiac care.' },
// { id: 's3', title: 'Orthopedics', description: 'Joint replacement, sports injury & fracture management.' },
// { id: 's4', title: 'Maternity & Neonatal', description: 'Comprehensive care for mother and child.' },
// { id: 's5', title: 'Diagnostics', description: 'MRI, CT, Ultrasound, Digital X-ray & Lab services.' },
// { id: 's6', title: 'Pharmacy', description: 'In-house pharmacy with verified medicines.' }
// ];


// const Services = () => {
// return (
// <div className="container">
// <h2>Our Services</h2>
// <div className="grid grid-3">
// {services.map(s => (
// <div key={s.id} className="card">
// <h3 style={{ marginTop:0 }}>{s.title}</h3>
// <p style={{ color:'var(--muted)' }}>{s.description}</p>
// </div>
// ))}
// </div>
// </div>
// );
// };


// export default Services;
import { Service } from '../types';

const services: Service[] = [
  { id: 's1', title: 'Emergency Care', description: '24/7 emergency services with advanced trauma support.' },
  { id: 's2', title: 'Cardiology', description: 'Non-invasive and interventional cardiac care.' },
  { id: 's3', title: 'Orthopedics', description: 'Joint replacement, sports injury & fracture management.' },
  { id: 's4', title: 'Maternity & Neonatal', description: 'Comprehensive care for mother and child.' },
  { id: 's5', title: 'Diagnostics', description: 'MRI, CT, Ultrasound, Digital X-ray & Lab services.' },
  { id: 's6', title: 'Pharmacy', description: 'In-house pharmacy with verified medicines.' }
];

const Services = () => {
  return (
    <div className="container">
      <h2>Our Services</h2>
      <div className="grid grid-3">
        {services.map(s => (
          <div key={s.id} className="card">
            <h3 style={{ marginTop: 0 }}>{s.title}</h3>
            <p style={{ color: 'var(--muted)' }}>{s.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Services;