// const About = () => (
// <div className="container">
// <h2>About AffordMed</h2>
// <div className="card">
// <p style={{ color:'var(--muted)' }}>
// AffordMed Hospital is committed to accessible, high-quality healthcare. This demo app showcases core hospital workflows: bed management, appointment booking, and pharmacy inventory — suitable for a coding assessment.
// </p>
// <ul>
// <li>Built with React + TypeScript</li>
// <li>State via context; storage via localStorage (fake API)</li>
// <li>Ready to connect to real backend (replace fakeApi with REST calls)</li>
// </ul>
// </div>
// </div>
// );
// export default About;
const About = () => (
  <div className="container">
    <h2>About AffordMed</h2>
    <div className="card">
      <p style={{ color: 'var(--muted)' }}>
        AffordMed Hospital is committed to accessible, high-quality healthcare. This demo app showcases core hospital workflows: bed management, appointment booking, and pharmacy inventory — suitable for a coding assessment.
      </p>
      <ul>
        <li>Built with React + TypeScript</li>
        <li>State via context; storage via localStorage (fake API)</li>
        <li>Ready to connect to real backend (replace fakeApi with REST calls)</li>
      </ul>
    </div>
  </div>
);
export default About;