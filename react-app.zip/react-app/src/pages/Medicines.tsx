// import { useState } from "react";

// interface Medicine {
//   id: number;
//   name: string;
//   brand: string;
//   stock: number;
//   price: number;
// }

// export default function Medicines() {
//   const [medicines] = useState<Medicine[]>([
//     { id: 1, name: "Paracetamol", brand: "Cipla", stock: 20, price: 15 },
//     { id: 2, name: "Amoxicillin", brand: "Sun Pharma", stock: 10, price: 120 },
//     { id: 3, name: "Vitamin D3", brand: "Dr. Reddy's", stock: 50, price: 60 },
//   ]);

//   return (
//     <div className="p-6">
//       <h2 className="text-xl font-bold mb-4">Medicine Inventory</h2>
//       <table className="table-auto border-collapse border border-gray-400 w-full">
//         <thead>
//           <tr className="bg-gray-200">
//             <th className="border px-4 py-2">Name</th>
//             <th className="border px-4 py-2">Brand</th>
//             <th className="border px-4 py-2">Stock</th>
//             <th className="border px-4 py-2">Price (₹)</th>
//             <th className="border px-4 py-2">Actions</th>
//           </tr>
//         </thead>
//         <tbody>
//           {medicines.map((m) => (
//             <tr key={m.id}>
//               <td className="border px-4 py-2">{m.name}</td>
//               <td className="border px-4 py-2">{m.brand}</td>
//               <td className="border px-4 py-2">{m.stock}</td>
//               <td className="border px-4 py-2">{m.price}</td>
//               <td className="border px-4 py-2">
//                 <button
//                   className="bg-blue-500 text-white px-2 py-1 rounded"
//                   onClick={() => alert(`Buying ${m.name}`)}
//                 >
//                   Buy
//                 </button>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// }
import { useMemo, useState } from 'react';
import { Medicine } from '../types';
import { api } from '../api/fakeApi';
import { useHospital } from '../context/HospitalContext';

const Medicines = () => {
  const { medicines, refresh } = useHospital();
  const [query, setQuery] = useState('');
  const [editing, setEditing] = useState<Medicine | null>(null);

  const filtered = useMemo(() =>
    medicines.filter(m => (m.name + ' ' + m.brand).toLowerCase().includes(query.toLowerCase())),
    [medicines, query]
  );

  const startEdit = (m?: Medicine) => setEditing(m ?? { id: '', name: '', brand: '', stock: 0, price: 0 });

  const save = async () => {
    if (!editing) return;
    if (!editing.name.trim()) return alert('Name is required');
    if (editing.stock < 0 || editing.price < 0) return alert('Stock and price must be non-negative');
    await api.upsertMedicine(editing);
    setEditing(null);
    await refresh();
  };

  const remove = async (id: string) => {
    if (confirm('Delete this medicine?')) {
      await api.deleteMedicine(id);
      await refresh();
    }
  };

  return (
    <div className="container">
      <h2>Pharmacy / Medicines</h2>
      <div className="card" style={{ marginBottom: 16 }}>
        <div className="row">
          <input className="input" placeholder="Search name/brand..." value={query} onChange={e => setQuery(e.target.value)} />
          <button className="btn" onClick={() => startEdit()}>Add Medicine</button>
        </div>
      </div>

      <div className="card">
        <table className="table">
          <thead>
            <tr><th>Name</th><th>Brand</th><th>Stock</th><th>Price (₹)</th><th>Actions</th></tr>
          </thead>
          <tbody>
            {filtered.map(m => (
              <tr key={m.id}>
                <td>{m.name}</td>
                <td>{m.brand}</td>
                <td>{m.stock}</td>
                <td>{m.price}</td>
                <td style={{ display: 'flex', gap: 8 }}>
                  <button className="btn secondary" onClick={() => startEdit(m)}>Edit</button>
                  <button className="btn danger" onClick={() => remove(m.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editing && (
        <div className="card" style={{ marginTop: 16 }}>
          <h3 style={{ marginTop: 0 }}>{editing.id ? 'Edit Medicine' : 'Add Medicine'}</h3>
          <div className="grid" style={{ gap: 12 }}>
            <div className="row">
              <div>
                <label className="label">Name</label>
                <input className="input" value={editing.name} onChange={e => setEditing({ ...editing, name: e.target.value })} />
              </div>
              <div>
                <label className="label">Brand</label>
                <input className="input" value={editing.brand} onChange={e => setEditing({ ...editing, brand: e.target.value })} />
              </div>
            </div>
            <div className="row">
              <div>
                <label className="label">Stock</label>
                <input className="input" type="number" value={editing.stock} onChange={e => setEditing({ ...editing, stock: Number(e.target.value) })} />
              </div>
              <div>
                <label className="label">Price (₹)</label>
                <input className="input" type="number" value={editing.price} onChange={e => setEditing({ ...editing, price: Number(e.target.value) })} />
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn" onClick={save}>Save</button>
              <button className="btn secondary" onClick={() => setEditing(null)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Medicines;