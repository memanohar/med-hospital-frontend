// import { FormEvent, useEffect, useState } from 'react';
// const toggleStatus = async (b: Bed) => {
// const next: BedStatus = b.status === 'Available' ? 'Occupied' : b.status === 'Occupied' ? 'Cleaning' : 'Available';
// await api.updateBed(b.id, { status: next });
// await refresh();
// };


// const removeBed = async (id: string) => { await api.deleteBed(id); await refresh(); };


// const available = beds.filter(b => b.status === 'Available').length;


// return (
// <div className="container">
// <h2>Hospital Beds</h2>
// <div className="grid grid-2">
// <div className="card">
// <h3 style={{ marginTop:0 }}>Register New Bed</h3>
// <form onSubmit={onSubmit} className="grid" style={{ gap:12 }}>
// <div>
// <label className="label">Ward</label>
// <input className="input" value={ward} onChange={e => setWard(e.target.value)} placeholder="e.g., A1" />
// </div>
// <div className="row">
// <div>
// <label className="label">Type</label>
// <select value={type} onChange={e => setType(e.target.value as BedType)}>
// {(['General','ICU','Emergency','Maternity'] as BedType[]).map(t => <option key={t} value={t}>{t}</option>)}
// </select>
// </div>
// <div>
// <label className="label">Status</label>
// <select value={status} onChange={e => setStatus(e.target.value as BedStatus)}>
// {(['Available','Occupied','Cleaning'] as BedStatus[]).map(s => <option key={s} value={s}>{s}</option>)}
// </select>
// </div>
// </div>
// <button className="btn" type="submit">Add Bed</button>
// </form>
// </div>


// <div className="card">
// <h3 style={{ marginTop:0 }}>Overview</h3>
// <p style={{ color:'var(--muted)' }}>Total: {beds.length} • Available: <span className="badge green">{available}</span></p>
// <table className="table">
// <thead>
// <tr><th>Ward</th><th>Type</th><th>Status</th><th>Actions</th></tr>
// </thead>
// <tbody>
// {beds.map(b => (
// <tr key={b.id}>
// <td>{b.ward}</td>
// <td>{b.type}</td>
// <td>
// <span className={`badge ${b.status==='Available'?'green':'red'}`}>{b.status}</span>
// </td>
// <td style={{ display:'flex', gap:8 }}>
// <button className="btn secondary" onClick={() => toggleStatus(b)}>Next Status</button>
// <button className="btn danger" onClick={() => removeBed(b.id)}>Delete</button>
// </td>
// </tr>
// ))}
// </tbody>
// </table>
// </div>
// </div>
// </div>
// );
// };


// export default Beds;
import { FormEvent, useState } from 'react';
import { Bed, BedStatus, BedType } from '../types';
import { api } from '../api/fakeApi';
import { useHospital } from '../context/HospitalContext';

const Beds = () => {
  const { beds, refresh } = useHospital();
  const [ward, setWard] = useState('');
  const [type, setType] = useState<BedType>('General');
  const [status, setStatus] = useState<BedStatus>('Available');

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!ward.trim()) return alert('Ward is required');
    await api.addBed({ ward, type, status });
    setWard(''); setType('General'); setStatus('Available');
    await refresh();
  };

  const toggleStatus = async (b: Bed) => {
    const next: BedStatus = b.status === 'Available' ? 'Occupied' : b.status === 'Occupied' ? 'Cleaning' : 'Available';
    await api.updateBed(b.id, { status: next });
    await refresh();
  };

  const removeBed = async (id: string) => {
    if (confirm('Delete this bed?')) {
      await api.deleteBed(id);
      await refresh();
    }
  };

  const available = beds.filter(b => b.status === 'Available').length;

  return (
    <div className="container">
      <h2>Hospital Beds</h2>
      <div className="grid grid-2">
        <div className="card">
          <h3 style={{ marginTop: 0 }}>Register New Bed</h3>
          <form onSubmit={onSubmit} className="grid" style={{ gap: 12 }}>
            <div>
              <label className="label">Ward</label>
              <input className="input" value={ward} onChange={e => setWard(e.target.value)} placeholder="e.g., A1" />
            </div>
            <div className="row">
              <div>
                <label className="label">Type</label>
                <select value={type} onChange={e => setType(e.target.value as BedType)}>
                  {(['General', 'ICU', 'Emergency', 'Maternity'] as BedType[]).map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Status</label>
                <select value={status} onChange={e => setStatus(e.target.value as BedStatus)}>
                  {(['Available', 'Occupied', 'Cleaning'] as BedStatus[]).map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>
            <button className="btn" type="submit">Add Bed</button>
          </form>
        </div>

        <div className="card">
          <h3 style={{ marginTop: 0 }}>Overview</h3>
          <p style={{ color: 'var(--muted)' }}>Total: {beds.length} • Available: <span className="badge green">{available}</span></p>
          <table className="table">
            <thead>
              <tr><th>Ward</th><th>Type</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {beds.map(b => (
                <tr key={b.id}>
                  <td>{b.ward}</td>
                  <td>{b.type}</td>
                  <td>
                    <span className={`badge ${b.status === 'Available' ? 'green' : 'red'}`}>{b.status}</span>
                  </td>
                  <td style={{ display: 'flex', gap: 8 }}>
                    <button className="btn secondary" onClick={() => toggleStatus(b)}>Next Status</button>
                    <button className="btn danger" onClick={() => removeBed(b.id)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Beds;