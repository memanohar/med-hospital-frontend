// import { useHospital } from '../context/HospitalContext';
// import StatCard from '../components/StatCard';
// import { Link } from 'react-router-dom';


// const Home = () => {
// const { beds, appointments, medicines } = useHospital();
// const availableBeds = beds.filter(b => b.status === 'Available').length;


// return (
// <div className="container hero">
// <div className="grid grid-2">
// <div className="card">
// <h1 style={{ marginTop:0 }}>Welcome to AffordMed Hospital</h1>
// <p style={{ color:'var(--muted)' }}>
// Quality care at affordable prices. Book doctor appointments, track bed availability, and manage pharmacy — all in one place.
// </p>
// <div style={{ display:'flex', gap:12, marginTop:16 }}>
// <Link to="/appointments" className="btn">Book Appointment</Link>
// <Link to="/beds" className="btn secondary">Check Beds</Link>
// </div>
// </div>
// <div className="grid grid-3">
// <StatCard title="Total Beds" value={beds.length} subtitle={`${availableBeds} available`} />
// <StatCard title="Appointments" value={appointments.length} subtitle="Today & upcoming" />
// <StatCard title="Medicines in Stock" value={medicines.reduce((a, m) => a + m.stock, 0)} subtitle={`${medicines.length} items`} />
// </div>
// </div>
// </div>
// );
// };


// export default Home;
import { useHospital } from '../context/HospitalContext';
import StatCard from '../components/StatCard';
import { Link } from 'react-router-dom';

const Home = () => {
  const { beds, appointments, medicines } = useHospital();
  const availableBeds = beds.filter(b => b.status === 'Available').length;

  return (
    <div className="container hero">
      <div className="grid grid-2">
        <div className="card">
          <h1 style={{ marginTop: 0 }}>Welcome to AffordMed Hospital</h1>
          <p style={{ color: 'var(--muted)' }}>
            Quality care at affordable prices. Book doctor appointments, track bed availability, and manage pharmacy — all in one place.
          </p>
          <div style={{ display: 'flex', gap: 12, marginTop: 16 }}>
            <Link to="/appointments" className="btn">Book Appointment</Link>
            <Link to="/beds" className="btn secondary">Check Beds</Link>
          </div>
        </div>
        <div className="grid grid-3">
          <StatCard title="Total Beds" value={beds.length} subtitle={`${availableBeds} available`} />
          <StatCard title="Appointments" value={appointments.length} subtitle="Today & upcoming" />
          <StatCard title="Medicines in Stock" value={medicines.reduce((a, m) => a + m.stock, 0)} subtitle={`${medicines.length} items`} />
        </div>
      </div>
    </div>
  );
};

export default Home;