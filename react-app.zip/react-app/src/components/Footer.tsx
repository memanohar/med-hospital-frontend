// const Footer = () => (
// <footer className="footer">
// <div className="container" style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
// <small className="muted">© {new Date().getFullYear()} AffordMed Technologies. All rights reserved.</small>
// <small className="muted">Made with ❤️ for demo purposes</small>
// </div>
// </footer>
// );
// export default Footer;
const Footer = () => (
  <footer className="footer">
    <div className="container" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <small className="muted">© {new Date().getFullYear()} AffordMed Technologies. All rights reserved.</small>
      <small className="muted">Made with ❤️ for demo purposes</small>
    </div>
  </footer>
);
export default Footer;