// import { Link, NavLink } from 'react-router-dom';


// const NavBar = () => {
// return (
// <header className="header">
// <div className="container" style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:12 }}>
// <Link to="/" style={{ display:'flex', alignItems:'center', gap:10 }}>
// <div style={{ width:36, height:36, borderRadius:10, background:'linear-gradient(135deg, var(--brand), var(--accent))' }} />
// <strong>AffordMed Hospital</strong>
// </Link>
// <nav style={{ display:'flex', gap:16 }}>
// {[
// ['/', 'Home'],
// ['/services', 'Services'],
// ['/beds', 'Beds'],
// ['/appointments', 'Appointments'],
// ['/medicines', 'Medicines'],
// ['/about', 'About']
// ].map(([to, label]) => (
// <NavLink key={to} to={to} className={({isActive}) => isActive ? 'badge green' : ''}>
// {label}
// </NavLink>
// ))}
// </nav>
// </div>
// </header>
// );
// };


// export default NavBar;
import { Link, NavLink } from 'react-router-dom';

const NavBar = () => {
  return (
    <header className="header">
      <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
        <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 10 }} aria-label="AffordMed Hospital Home">
          <div style={{ width: 36, height: 36, borderRadius: 10, background: 'linear-gradient(135deg, var(--brand), var(--accent))' }} />
          <strong>AffordMed Hospital</strong>
        </Link>
        <nav style={{ display: 'flex', gap: 16 }}>
          {[
            ['/', 'Home'],
            ['/services', 'Services'],
            ['/beds', 'Beds'],
            ['/appointments', 'Appointments'],
            ['/medicines', 'Medicines'],
            ['/about', 'About']
          ].map(([to, label]) => (
            <NavLink key={to} to={to} className={({ isActive }) => (isActive ? 'badge green' : '')}>
              {label}
            </NavLink>
          ))}
        </nav>
      </div>
    </header>
  );
};

export default NavBar;