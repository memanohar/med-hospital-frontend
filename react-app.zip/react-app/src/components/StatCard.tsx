// interface Props { title: string; value: string | number; subtitle?: string }
// const StatCard = ({ title, value, subtitle }: Props) => (
// <div className="card">
// <div style={{ color:'var(--muted)', fontSize:12 }}>{title}</div>
// <div style={{ fontSize:28, fontWeight:700, marginTop:6 }}>{value}</div>
// {subtitle && <div style={{ color:'var(--muted)', marginTop:6 }}>{subtitle}</div>}
// </div>
// );
// export default StatCard;
interface Props { title: string; value: string | number; subtitle?: string }
const StatCard = ({ title, value, subtitle }: Props) => (
  <div className="card">
    <div style={{ color: 'var(--muted)', fontSize: 12 }}>{title}</div>
    <div style={{ fontSize: 28, fontWeight: 700, marginTop: 6 }}>{value}</div>
    {subtitle && <div style={{ color: 'var(--muted)', marginTop: 6 }}>{subtitle}</div>}
  </div>
);
export default StatCard;