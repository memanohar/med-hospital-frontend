import React, { createContext, useContext, useEffect, useState } from 'react';
import { Appointment, Bed, Medicine } from '../types';
import { api } from '../api/fakeApi';


interface HospitalContextType {
beds: Bed[];
appointments: Appointment[];
medicines: Medicine[];
refresh: () => Promise<void>;
}


const HospitalContext = createContext<HospitalContextType | null>(null);


export const useHospital = () => {
const ctx = useContext(HospitalContext);
if (!ctx) throw new Error('useHospital must be used within HospitalProvider');
return ctx;
};


export const HospitalProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
const [beds, setBeds] = useState<Bed[]>([]);
const [appointments, setAppointments] = useState<Appointment[]>([]);
const [medicines, setMedicines] = useState<Medicine[]>([]);


const refresh = async () => {
const [b, a, m] = await Promise.all([api.getBeds(), api.getAppointments(), api.getMedicines()]);
setBeds(b); setAppointments(a); setMedicines(m);
};


useEffect(() => { refresh(); }, []);


return (
<HospitalContext.Provider value={{ beds, appointments, medicines, refresh }}>
{children}
</HospitalContext.Provider>
);
};